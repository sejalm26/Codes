

function Button({count, onClick}) {

    return (
        <button onClick={onClick}>Count: {count}</button>
    )
}

export default Button;



//   x                       y
//  func1                         import func1
// export funct1                