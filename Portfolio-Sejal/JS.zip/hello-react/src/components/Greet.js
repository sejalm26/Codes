import Button from "./Button";
import React, { useState } from "react";

const userData = {
  name: "Raj kapoor",
  age: 25,
  location: "India"
};


const skills = [
    {id:1, skill: "HTML"},  // <li key={1}>HTML</li>
    {id:2, skill: "CSS"},   // <li key={2}>CSS</li>
    {id:3, skill: "JavaScript"},
    {id:4, skill: "React"}
];

const skillsList = skills.map((skill) => <li key={skill.id}>{skill.skill}</li>);




function Greet({count, onClick}){


  return (
    <div>
      <h1>Name: {userData.name}</h1>
      <p> Age : {userData.age}</p>
      <p>Location : {userData.location}</p>
      <ul>{skillsList}</ul>
      <Button count={count} onClick={onClick}/>
      <Button count={count} onClick={onClick}/>
    </div>
  )
};


export default Greet;




/*


arr1 = [ 2 , 4 , 6 , 8 , 10]

arr2 = arr1.map( num => num*2)

[ 4 , 8 , 12 , 16 , 20]

arr1 = [{id:2 , skill="python"} , 4 , 6 , 8 , 10]  

arr2 = arr1.map(x => <li id={x.id}>{x.skill} </li>) 













*/