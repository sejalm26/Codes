
console.log("Hello, World!");
// Revise - 5min

// console.log
// variables - let const          var
// if else 
// for while
// break continue

