const [count , setCount] = useState(0);



//     10  
//  +   -
// setCount(1)
// setCount(10)
// setCount(count+1) --> 11
// setCount(count+1) --> 12
// setCount(count+1) --> 13
// setCount(count+1) --> 14
// setCount(count-1)-->13
// setCount(count-1)-->12