
// console.log
// variables - let const          var
// if else 
// for while
// break continue

let num1 =

if(num1 > 0) {
    console.log("Number is Positive");
}else if(num1 <0){
    console.log("Number is Negative");
}else{
    console.log("Number is Zero");
}
